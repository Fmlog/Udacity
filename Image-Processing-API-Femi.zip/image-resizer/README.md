# Image Resizer Udacity Assignment

## Scripts
* To run development server 
> npm run start

* To build production code
> npm run start

* To lint code
> npm run lint

* To test production code
> npm run test

## Endpoints
* /api/image?filename=[]&width=[]&height=[]

